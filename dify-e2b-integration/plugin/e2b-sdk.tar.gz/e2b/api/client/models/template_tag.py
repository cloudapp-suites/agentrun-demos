import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="TemplateTag")


@_attrs_define
class TemplateTag:
    """
    Attributes:
        build_id (UUID): Identifier of the build associated with this tag
        created_at (datetime.datetime): Time when the tag was assigned
        tag (str): The tag name
    """

    build_id: UUID
    created_at: datetime.datetime
    tag: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        build_id = str(self.build_id)

        created_at = self.created_at.isoformat()

        tag = self.tag

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "buildID": build_id,
                "createdAt": created_at,
                "tag": tag,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        build_id = UUID(d.pop("buildID"))

        created_at = isoparse(d.pop("createdAt"))

        tag = d.pop("tag")

        template_tag = cls(
            build_id=build_id,
            created_at=created_at,
            tag=tag,
        )

        template_tag.additional_properties = d
        return template_tag

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
